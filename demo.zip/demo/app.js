/*
* @Author: Administrator
* @Date:   2017-08-04 08:30:14
* @Last Modified by:   Administrator
* @Last Modified time: 2017-08-04 10:24:55
*/

'use strict';
var mongoose = require('mongoose');
mongoose.connect('mongodb://localhost/mongoose');

var Cat = mongoose.model('Cat', { name: String });

var kitty = new Cat({ name: 'smallcat' });
kitty.save(function (err) {
  if (err) {
    console.log(err);
  } else {
    console.log('sc');
  }
});